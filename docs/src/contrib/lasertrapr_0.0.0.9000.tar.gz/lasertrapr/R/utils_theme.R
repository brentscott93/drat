
#' The color pink
#' @noRd

pink <- function(){
  '#F012BE'
}

#' Title
#' @noRd
purple <- function(){
  '#605ca8'
} 

#' The color maroon
#' @noRd
maroon <- function(){
  '#D81B60'
} 

#' The color green
#' @noRd
green <- function(){
  '#01FF70'
}

#' The color gray
#' @noRd

trap_gray <- function(){
'#484848'
}

#' Theme for app
#' @noRd
theme_lasertrapr <- function(...){
  fresh::create_theme(
  fresh::adminlte_color(
    light_blue = "#141313",
    green = pink(),
    yellow = purple(),
    red = maroon()
  ),
   fresh::adminlte_sidebar(
  #   width = "400px",
      dark_bg = "#141313"
  #   dark_hover_bg = "#81A1C1",
  #   dark_color = "#2E3440"
   ),
  fresh::adminlte_global(
    content_bg = '#333333',
    #box_bg =  '#a7a7a7',
    #box_bg = "#e0cee3"#,
    #info_box_bg = "#D8DEE9"
  )
  # fresh::adminlte_vars(
  #  # 'box-default-border-top-color' = pink()
  # ), ...
)
}



#' Dark theme - thanks (https://gist.github.com/jslefche/eff85ef06b4705e6efbc)
#' @noRd
#' @export

theme_black <- function(base_size = 12, base_family = "") {
  
  theme_grey(base_size = base_size, base_family = base_family) %+replace%
    
    theme(
      # Specify axis options
      axis.line = element_blank(),  
      axis.text.x = element_text(size = base_size*0.8, color = "white", lineheight = 0.9),  
      axis.text.y = element_text(size = base_size*0.8, color = "white", lineheight = 0.9),  
      axis.ticks = element_line(color = "white", size  =  0.2),  
      axis.title.x = element_text(size = base_size, color = "white", margin = margin(0, 10, 0, 0)),  
      axis.title.y = element_text(size = base_size, color = "white", angle = 90, margin = margin(0, 10, 0, 0)),  
      axis.ticks.length = unit(0.3, "lines"),   
      # Specify legend options
      legend.background = element_rect(color = NA, fill = "black"),  
      legend.key = element_rect(color = NA,  fill = "black"),  
      legend.key.size = unit(1.2, "lines"),  
      legend.key.height = NULL,  
      legend.key.width = NULL,      
      legend.text = element_text(size = base_size*0.8, color = "white"),  
      legend.title = element_text(size = base_size*0.8, face = "bold", hjust = 0, color = "white"),  
      legend.position = "right",  
      legend.text.align = NULL,  
      legend.title.align = NULL,  
      legend.direction = "vertical",  
      legend.box = NULL, 
      # Specify panel options
      panel.background = element_rect(fill = "black", color  =  NA),  
      panel.border = element_rect(fill = NA, color = "white"),  
      panel.grid.major = element_blank(),  
      panel.grid.minor = element_blank(),  
      panel.spacing = unit(0.5, "lines"),   
      # Specify facetting options
      strip.background = element_rect(fill = "#323232", color = "grey10"),  
      strip.text.x = element_text(size = base_size*0.8, color = "white"),  
      strip.text.y = element_text(size = base_size*0.8, color = "white",angle = -90),  
      # Specify plot options
      plot.background = element_rect(color = "black", fill = "black"),  
      plot.title = element_text(size = base_size*1.2, color = "white"),  
      plot.margin = unit(rep(1, 4), "lines")
      
    )
  
}

