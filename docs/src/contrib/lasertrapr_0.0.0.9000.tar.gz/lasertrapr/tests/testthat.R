library(testthat)
library(lasertrapr)

test_check("lasertrapr")
